# process_viewer.py

import psutil

def list_processes():
    process_list = []

    try:
        for process in psutil.process_iter(["pid", "name"]):
            info = process.info

            process_list.append({
                "pid": info.get("pid"),
                "name": info.get("name")
            })

        return {
            "tool": "Process Viewer",
            "processes": process_list
        }

    except Exception as e:
        return {
            "tool": "Process Viewer",
            "error": str(e)
        }