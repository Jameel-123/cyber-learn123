# service_checker.py

def get_service_name(port):
    services = {
        20: "FTP-DATA",
        21: "FTP",
        22: "SSH",
        23: "TELNET",
        25: "SMTP",
        53: "DNS",
        80: "HTTP",
        110: "POP3",
        135: "MSRPC",
        139: "NETBIOS",
        143: "IMAP",
        443: "HTTPS",
        445: "SMB",
        3306: "MYSQL",
        3389: "RDP",
        5432: "POSTGRESQL",
        8080: "HTTP-ALT"
    }

    if port in services:
        return services[port]
    else:
        return "Unknown"


def check_service(port):
    return {
        "tool": "Service Checker",
        "port": port,
        "service": get_service_name(port)
    }