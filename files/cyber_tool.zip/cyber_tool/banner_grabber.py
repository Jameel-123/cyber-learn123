# banner_grabber.py

import socket

def grab_banner(host, port, timeout=2):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))

        if port in [80, 8080, 8000]:
            request = "HEAD / HTTP/1.0\r\n\r\n"
            s.send(request.encode())

        banner = s.recv(1024)
        s.close()

        text = banner.decode(errors="ignore").strip()

        if text == "":
            text = "No banner found"

        return {
            "tool": "Banner Grabber",
            "target": host,
            "port": port,
            "banner": text
        }

    except:
        return {
            "tool": "Banner Grabber",
            "target": host,
            "port": port,
            "banner": "Could not grab banner"
        }