# uploader.py

import os
import requests
from config import UPLOAD_URL

def upload_report(file_path, api_key):
    if not os.path.exists(file_path):
        return "Report file does not exist"

    headers = {
        "Authorization": f"Bearer {api_key}"
    }

    try:
        with open(file_path, "rb") as file:
            files = {"report": file}

            response = requests.post(
                UPLOAD_URL,
                headers=headers,
                files=files,
                timeout=10
            )

        if response.status_code == 200 or response.status_code == 201:
            return "Report uploaded successfully"
        elif response.status_code == 401:
            return "Invalid API key"
        elif response.status_code == 403:
            return "Access denied"
        else:
            return f"Upload failed: {response.status_code} {response.text}"

    except Exception as e:
        return f"Upload error: {e}"