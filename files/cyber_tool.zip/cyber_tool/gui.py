# gui.py

# Main GUI file for the app

import tkinter as tk
from tkinter import filedialog, messagebox
import json

# Import each tool from a different file
from port_scanner import scan_ports
from service_checker import check_service
from banner_grabber import grab_banner
from process_viewer import list_processes
from file_hasher import hash_file
from reporting import save_report, load_report
from uploader import upload_report


class ToolGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Cybersecurity Toolkit")
        self.root.geometry("950x650")

        self.make_pages()
        self.show_page(self.main_page)

    def make_pages(self):
        self.main_page = tk.Frame(self.root)
        self.port_scan_page = tk.Frame(self.root)
        self.service_page = tk.Frame(self.root)
        self.banner_page = tk.Frame(self.root)
        self.process_page = tk.Frame(self.root)
        self.hasher_page = tk.Frame(self.root)
        self.report_page = tk.Frame(self.root)
        self.upload_page = tk.Frame(self.root)

        self.build_main_page()
        self.build_port_scan_page()
        self.build_service_page()
        self.build_banner_page()
        self.build_process_page()
        self.build_hasher_page()
        self.build_report_page()
        self.build_upload_page()

    def show_page(self, page):
        for frame in [
            self.main_page,
            self.port_scan_page,
            self.service_page,
            self.banner_page,
            self.process_page,
            self.hasher_page,
            self.report_page,
            self.upload_page
        ]:
            frame.pack_forget()

        page.pack(fill="both", expand=True)

    def build_main_page(self):
        tk.Label(
            self.main_page,
            text="Cybersecurity Toolkit",
            font=("Arial", 18, "bold")
        ).pack(pady=20)

        tk.Label(
            self.main_page,
            text=(
                "Select a tool below.\n\n"
                "1. Port Scanner\n"
                "2. Service Checker\n"
                "3. Banner Grabber\n"
                "4. Process Viewer\n"
                "5. File Hasher\n"
                "6. Report Viewer\n"
                "7. Upload Report"
            ),
            font=("Arial", 12),
            justify="left"
        ).pack(pady=10)

        button_frame = tk.Frame(self.main_page)
        button_frame.pack(pady=20)

        tk.Button(button_frame, text="Port Scanner", width=20, command=lambda: self.show_page(self.port_scan_page)).grid(row=0, column=0, padx=10, pady=10)
        tk.Button(button_frame, text="Service Checker", width=20, command=lambda: self.show_page(self.service_page)).grid(row=0, column=1, padx=10, pady=10)
        tk.Button(button_frame, text="Banner Grabber", width=20, command=lambda: self.show_page(self.banner_page)).grid(row=1, column=0, padx=10, pady=10)
        tk.Button(button_frame, text="Process Viewer", width=20, command=lambda: self.show_page(self.process_page)).grid(row=1, column=1, padx=10, pady=10)
        tk.Button(button_frame, text="File Hasher", width=20, command=lambda: self.show_page(self.hasher_page)).grid(row=2, column=0, padx=10, pady=10)
        tk.Button(button_frame, text="Report Viewer", width=20, command=lambda: self.show_page(self.report_page)).grid(row=2, column=1, padx=10, pady=10)
        tk.Button(button_frame, text="Upload Report", width=20, command=lambda: self.show_page(self.upload_page)).grid(row=3, column=0, padx=10, pady=10)

    def build_port_scan_page(self):
        tk.Label(self.port_scan_page, text="Port Scanner", font=("Arial", 16, "bold")).pack(pady=10)
        tk.Button(self.port_scan_page, text="Back", command=lambda: self.show_page(self.main_page)).pack(pady=5)

        frame = tk.Frame(self.port_scan_page)
        frame.pack(pady=10)

        tk.Label(frame, text="Target IP or hostname").grid(row=0, column=0, padx=10, pady=10)
        self.scan_target_entry = tk.Entry(frame, width=30)
        self.scan_target_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(frame, text="Ports").grid(row=1, column=0, padx=10, pady=10)
        self.scan_ports_entry = tk.Entry(frame, width=30)
        self.scan_ports_entry.insert(0, "1-100")
        self.scan_ports_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Button(self.port_scan_page, text="Run Port Scan", command=self.run_port_scan).pack(pady=10)
        self.port_scan_text = tk.Text(self.port_scan_page, height=18, width=100)
        self.port_scan_text.pack(padx=10, pady=10)

    def build_service_page(self):
        tk.Label(self.service_page, text="Service Checker", font=("Arial", 16, "bold")).pack(pady=10)
        tk.Button(self.service_page, text="Back", command=lambda: self.show_page(self.main_page)).pack(pady=5)

        frame = tk.Frame(self.service_page)
        frame.pack(pady=10)

        tk.Label(frame, text="Port number").grid(row=0, column=0, padx=10, pady=10)
        self.service_port_entry = tk.Entry(frame, width=20)
        self.service_port_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Button(self.service_page, text="Check Service", command=self.run_service_check).pack(pady=10)
        self.service_text = tk.Text(self.service_page, height=12, width=100)
        self.service_text.pack(padx=10, pady=10)

    def build_banner_page(self):
        tk.Label(self.banner_page, text="Banner Grabber", font=("Arial", 16, "bold")).pack(pady=10)
        tk.Button(self.banner_page, text="Back", command=lambda: self.show_page(self.main_page)).pack(pady=5)

        frame = tk.Frame(self.banner_page)
        frame.pack(pady=10)

        tk.Label(frame, text="Target IP or hostname").grid(row=0, column=0, padx=10, pady=10)
        self.banner_target_entry = tk.Entry(frame, width=30)
        self.banner_target_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(frame, text="Port").grid(row=1, column=0, padx=10, pady=10)
        self.banner_port_entry = tk.Entry(frame, width=20)
        self.banner_port_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Button(self.banner_page, text="Grab Banner", command=self.run_banner_grab).pack(pady=10)
        self.banner_text = tk.Text(self.banner_page, height=14, width=100)
        self.banner_text.pack(padx=10, pady=10)

    def build_process_page(self):
        tk.Label(self.process_page, text="Process Viewer", font=("Arial", 16, "bold")).pack(pady=10)
        tk.Button(self.process_page, text="Back", command=lambda: self.show_page(self.main_page)).pack(pady=5)

        tk.Button(self.process_page, text="Show Processes", command=self.run_process_view).pack(pady=10)
        self.process_text = tk.Text(self.process_page, height=20, width=100)
        self.process_text.pack(padx=10, pady=10)

    def build_hasher_page(self):
        tk.Label(self.hasher_page, text="File Hasher", font=("Arial", 16, "bold")).pack(pady=10)
        tk.Button(self.hasher_page, text="Back", command=lambda: self.show_page(self.main_page)).pack(pady=5)

        frame = tk.Frame(self.hasher_page)
        frame.pack(pady=10)

        tk.Label(frame, text="Choose file").grid(row=0, column=0, padx=10, pady=10)
        self.hash_file_entry = tk.Entry(frame, width=50)
        self.hash_file_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Button(frame, text="Browse", command=self.pick_hash_file).grid(row=0, column=2, padx=10, pady=10)

        tk.Label(frame, text="Algorithm").grid(row=1, column=0, padx=10, pady=10)
        self.hash_algo = tk.StringVar()
        self.hash_algo.set("sha256")
        tk.OptionMenu(frame, self.hash_algo, "md5", "sha1", "sha256", "sha512").grid(row=1, column=1, padx=10, pady=10, sticky="w")

        tk.Button(self.hasher_page, text="Generate Hash", command=self.run_hash).pack(pady=10)
        self.hash_text = tk.Text(self.hasher_page, height=18, width=100)
        self.hash_text.pack(padx=10, pady=10)

    def build_report_page(self):
        tk.Label(self.report_page, text="Report Viewer", font=("Arial", 16, "bold")).pack(pady=10)
        tk.Button(self.report_page, text="Back", command=lambda: self.show_page(self.main_page)).pack(pady=5)

        frame = tk.Frame(self.report_page)
        frame.pack(pady=10)

        tk.Label(frame, text="Choose report").grid(row=0, column=0, padx=10, pady=10)
        self.report_entry = tk.Entry(frame, width=50)
        self.report_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Button(frame, text="Browse", command=self.pick_report_file).grid(row=0, column=2, padx=10, pady=10)

        tk.Button(self.report_page, text="Load Report", command=self.show_report).pack(pady=10)
        self.report_text = tk.Text(self.report_page, height=18, width=100)
        self.report_text.pack(padx=10, pady=10)

    def build_upload_page(self):
        tk.Label(self.upload_page, text="Upload Report", font=("Arial", 16, "bold")).pack(pady=10)
        tk.Button(self.upload_page, text="Back", command=lambda: self.show_page(self.main_page)).pack(pady=5)

        frame = tk.Frame(self.upload_page)
        frame.pack(pady=10)

        tk.Label(frame, text="Choose report").grid(row=0, column=0, padx=10, pady=10)
        self.upload_entry = tk.Entry(frame, width=50)
        self.upload_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Button(frame, text="Browse", command=self.pick_upload_file).grid(row=0, column=2, padx=10, pady=10)

        tk.Label(frame, text="API key").grid(row=1, column=0, padx=10, pady=10)
        self.api_entry = tk.Entry(frame, width=50, show="*")
        self.api_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Button(self.upload_page, text="Upload Report", command=self.run_upload).pack(pady=10)
        self.upload_text = tk.Text(self.upload_page, height=16, width=100)
        self.upload_text.pack(padx=10, pady=10)

    def run_port_scan(self):
        target = self.scan_target_entry.get().strip()
        ports_text = self.scan_ports_entry.get().strip()

        if target == "":
            messagebox.showerror("Error", "Please enter a target")
            return

        if ports_text == "":
            messagebox.showerror("Error", "Please enter a port or range")
            return

        try:
            result = scan_ports(target, ports_text)
            report_path = save_report(result, target)

            self.port_scan_text.delete("1.0", tk.END)
            self.port_scan_text.insert(tk.END, json.dumps(result, indent=4))
            self.port_scan_text.insert(tk.END, f"\n\nReport saved to:\n{report_path}")

            self.report_entry.delete(0, tk.END)
            self.report_entry.insert(0, report_path)

            self.upload_entry.delete(0, tk.END)
            self.upload_entry.insert(0, report_path)

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def run_service_check(self):
        port_text = self.service_port_entry.get().strip()

        if port_text == "":
            messagebox.showerror("Error", "Please enter a port number")
            return

        try:
            port = int(port_text)
            result = check_service(port)

            self.service_text.delete("1.0", tk.END)
            self.service_text.insert(tk.END, json.dumps(result, indent=4))

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def run_banner_grab(self):
        target = self.banner_target_entry.get().strip()
        port_text = self.banner_port_entry.get().strip()

        if target == "":
            messagebox.showerror("Error", "Please enter a target")
            return

        if port_text == "":
            messagebox.showerror("Error", "Please enter a port")
            return

        try:
            port = int(port_text)
            result = grab_banner(target, port)
            report_path = save_report(result, f"{target}_{port}")

            self.banner_text.delete("1.0", tk.END)
            self.banner_text.insert(tk.END, json.dumps(result, indent=4))
            self.banner_text.insert(tk.END, f"\n\nReport saved to:\n{report_path}")

            self.report_entry.delete(0, tk.END)
            self.report_entry.insert(0, report_path)

            self.upload_entry.delete(0, tk.END)
            self.upload_entry.insert(0, report_path)

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def run_process_view(self):
        result = list_processes()
        report_path = save_report(result, "processes")

        self.process_text.delete("1.0", tk.END)
        self.process_text.insert(tk.END, json.dumps(result, indent=4))
        self.process_text.insert(tk.END, f"\n\nReport saved to:\n{report_path}")

        self.report_entry.delete(0, tk.END)
        self.report_entry.insert(0, report_path)

        self.upload_entry.delete(0, tk.END)
        self.upload_entry.insert(0, report_path)

    def pick_hash_file(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            self.hash_file_entry.delete(0, tk.END)
            self.hash_file_entry.insert(0, file_path)

    def run_hash(self):
        file_path = self.hash_file_entry.get().strip()
        algorithm = self.hash_algo.get()

        if file_path == "":
            messagebox.showerror("Error", "Please choose a file")
            return

        result = hash_file(file_path, algorithm)
        report_path = save_report(result, "file_hash")

        self.hash_text.delete("1.0", tk.END)
        self.hash_text.insert(tk.END, json.dumps(result, indent=4))
        self.hash_text.insert(tk.END, f"\n\nReport saved to:\n{report_path}")

        self.report_entry.delete(0, tk.END)
        self.report_entry.insert(0, report_path)

        self.upload_entry.delete(0, tk.END)
        self.upload_entry.insert(0, report_path)

    def pick_report_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")])
        if file_path:
            self.report_entry.delete(0, tk.END)
            self.report_entry.insert(0, file_path)

    def show_report(self):
        file_path = self.report_entry.get().strip()

        if file_path == "":
            messagebox.showerror("Error", "Please choose a report")
            return

        try:
            data = load_report(file_path)
            self.report_text.delete("1.0", tk.END)
            self.report_text.insert(tk.END, json.dumps(data, indent=4))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def pick_upload_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")])
        if file_path:
            self.upload_entry.delete(0, tk.END)
            self.upload_entry.insert(0, file_path)

    def run_upload(self):
        file_path = self.upload_entry.get().strip()
        api_key = self.api_entry.get().strip()

        if file_path == "":
            messagebox.showerror("Error", "Please choose a report")
            return

        if api_key == "":
            messagebox.showerror("Error", "Please enter your API key")
            return

        result = upload_report(file_path, api_key)

        self.upload_text.delete("1.0", tk.END)
        self.upload_text.insert(tk.END, result)


def main():
    root = tk.Tk()
    app = ToolGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()