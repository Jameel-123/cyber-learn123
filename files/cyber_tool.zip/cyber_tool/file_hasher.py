# file_hasher.py

import os
import hashlib

def hash_file(file_path, algorithm="sha256"):
    if not os.path.exists(file_path):
        return {
            "tool": "File Hasher",
            "error": "File not found"
        }

    try:
        hash_object = hashlib.new(algorithm)

        with open(file_path, "rb") as file:
            chunk = file.read(4096)

            while chunk:
                hash_object.update(chunk)
                chunk = file.read(4096)

        return {
            "tool": "File Hasher",
            "file": file_path,
            "algorithm": algorithm,
            "hash": hash_object.hexdigest()
        }

    except Exception as e:
        return {
            "tool": "File Hasher",
            "error": str(e)
        }