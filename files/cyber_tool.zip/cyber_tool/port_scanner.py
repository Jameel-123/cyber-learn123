import socket

def check_port(host, port, timeout=1):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        result = s.connect_ex((host, port))
        s.close()
        return result == 0
    except:
        return False


def scan_ports(host, ports_text):
    open_ports = []

    if "-" in ports_text:
        start, end = ports_text.split("-")
        for port in range(int(start), int(end) + 1):
            if check_port(host, port):
                open_ports.append(port)
    else:
        port = int(ports_text)
        if check_port(host, port):
            open_ports.append(port)

    return {
        "tool": "Port Scanner",
        "target": host,
        "open_ports": open_ports
    }