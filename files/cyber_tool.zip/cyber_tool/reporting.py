# reporting.py

import json
import os
from datetime import datetime
from config import REPORT_FOLDER

def make_filename(name):
    name = name.replace(":", "_")
    name = name.replace("/", "_")
    name = name.replace("\\", "_")
    name = name.replace(" ", "_")

    current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"report_{name}_{current_time}.json"


def save_report(data, name="output"):
    if not os.path.exists(REPORT_FOLDER):
        os.makedirs(REPORT_FOLDER)

    filename = make_filename(name)
    full_path = os.path.join(REPORT_FOLDER, filename)

    with open(full_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=4)

    return full_path


def load_report(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        data = json.load(file)

    return data