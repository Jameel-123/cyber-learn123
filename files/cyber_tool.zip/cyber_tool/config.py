# config.py

REPORT_FOLDER = "reports"
UPLOAD_URL = "http://127.0.0.1:5000/api/upload-report"